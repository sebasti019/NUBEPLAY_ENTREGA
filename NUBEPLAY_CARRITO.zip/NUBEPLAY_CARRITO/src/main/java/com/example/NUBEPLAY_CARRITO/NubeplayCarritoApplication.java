package com.example.NUBEPLAY_CARRITO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NubeplayCarritoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NubeplayCarritoApplication.class, args);
	}

}
