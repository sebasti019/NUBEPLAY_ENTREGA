package com.example.NUBEPLAY_CARRITO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NubeplayCarritoApplicationTests {

	@Test
	void contextLoads() {
	}

}
