package com.example.NUBEPLAY_USUARIO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NubeplayUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
