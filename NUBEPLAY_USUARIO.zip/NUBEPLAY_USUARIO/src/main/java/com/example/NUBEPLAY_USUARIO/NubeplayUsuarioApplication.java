package com.example.NUBEPLAY_USUARIO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NubeplayUsuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(NubeplayUsuarioApplication.class, args);
	}

}
