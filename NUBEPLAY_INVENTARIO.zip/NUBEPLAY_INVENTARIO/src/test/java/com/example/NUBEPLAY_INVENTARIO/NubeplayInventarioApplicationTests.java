package com.example.NUBEPLAY_INVENTARIO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NubeplayInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
