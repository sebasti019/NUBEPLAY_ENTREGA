package com.example.NUBEPLAY_INVENTARIO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NubeplayInventarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(NubeplayInventarioApplication.class, args);
	}

}
